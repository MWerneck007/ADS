/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Stats from './components/Stats';
import Services from './components/Services';
import WhyChooseUs from './components/WhyChooseUs';
import Gallery from './components/Gallery';
import Team from './components/Team';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Location from './components/Location';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  const [activeSection, setActiveSection] = useState('inicio');

  useEffect(() => {
    const sections = [
      'inicio',
      'sobre',
      'servicos',
      'diferenciais',
      'galeria',
      'equipe',
      'depoimentos',
      'faq',
      'contato'
    ];

    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200; // Offset for navbar height and visual triggers

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;

          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    // Initialize check once on mount
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="relative min-h-screen flex flex-col font-sans" id="aistudio-app-wrapper">
      {/* Dynamic Headers & Active Sections */}
      <Navbar activeSection={activeSection} />

      <main className="flex-grow">
        {/* Render fully polished and validated components */}
        <Hero />
        <About />
        <Stats />
        <Services />
        <WhyChooseUs />
        <Gallery />
        <Team />
        <Testimonials />
        <FAQ />
        <Location />
        <Contact />
      </main>

      <Footer />
    </div>
  );
}
