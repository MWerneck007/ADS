/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ServiceItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  iconName: string; // Dynamic rendering from Lucide
  details: string[];
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  imageUrl: string;
  linkedin?: string;
  instagram?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  description: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  company: string;
  role: string;
  text: string;
  rating: number;
  imageUrl: string;
}

export interface ValueItem {
  title: string;
  description: string;
  iconName: string;
}

export interface StatItem {
  number: string;
  label: string;
  suffix?: string;
}
