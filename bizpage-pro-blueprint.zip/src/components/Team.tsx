/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { TIME } from '../data';
import { Linkedin, Instagram, Sparkles } from 'lucide-react';

export default function Team() {
  return (
    <section
      id="equipe"
      className="py-24 bg-[#0a0a0a] relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 font-sans">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-brand-gold uppercase">
            Mentes por Trás do Design
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mt-2 mb-4">
            Nossa Equipe de Especialistas
          </h2>
          <p className="text-sm sm:text-base text-brand-charcoal/80 leading-relaxed font-light">
            Um time multidisciplinar composto por arquitetos visionários, botânicos aplicados e engenheiros de ponta comprometidos com as novas formas de viver.
          </p>
          <div className="w-16 h-1 bg-brand-gold mx-auto mt-4 rounded-full" />
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-10" id="team-grid">
          {TIME.map((member) => (
            <div
              key={member.id}
              className="bg-[#121212]/90 rounded-3xl p-6 border border-brand-gold/15 hover:border-brand-gold/45 transition-all duration-300 flex flex-col items-center text-center group shadow-2xl"
            >
              {/* Profile Image Frame */}
              <div className="relative w-40 h-40 rounded-full overflow-hidden border-4 border-brand-gold/25 shadow-md mb-6 shrink-0 aspect-square">
                <img
                  src={member.imageUrl}
                  alt={member.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual Accent Corner Glow */}
                <div className="absolute inset-0 bg-gradient-to-tr from-brand-gold/10 to-transparent pointer-events-none" />
              </div>

              {/* Roles Description */}
              <h3 className="text-lg font-serif font-bold text-white">
                {member.name}
              </h3>
              <p className="text-xs font-mono text-brand-gold font-bold uppercase tracking-widest mt-1 mb-4">
                {member.role}
              </p>

              {/* Bio description */}
              <p className="text-xs sm:text-sm text-brand-charcoal/80 leading-relaxed font-light flex-grow px-2">
                {member.bio}
              </p>

              {/* Connected details */}
              <div className="flex items-center gap-3 mt-6 pt-5 border-t border-brand-gold/15 w-full justify-center">
                {member.linkedin && (
                  <a
                    href={member.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-full bg-white/5 hover:bg-brand-gold border border-brand-gold/20 flex items-center justify-center text-brand-gold hover:text-black transition-colors"
                    aria-label={`LinkedIn de ${member.name}`}
                  >
                    <Linkedin className="w-4 h-4" />
                  </a>
                )}
                {member.instagram && (
                  <a
                    href={member.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-full bg-white/5 hover:bg-brand-gold border border-brand-gold/20 flex items-center justify-center text-brand-gold hover:text-black transition-colors"
                    aria-label={`Instagram de ${member.name}`}
                  >
                    <Instagram className="w-4 h-4" />
                  </a>
                )}
                <div className="flex items-center gap-1 text-[10px] font-mono font-bold text-[#9D8466] uppercase tracking-wider ml-2">
                  <Sparkles className="w-3 h-3 text-brand-gold" />
                  <span>Aura Partner</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
