/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Leaf, Instagram, Linkedin, Youtube, ArrowUp, MapPin, Mail, Phone, Calendar } from 'lucide-react';
import { COMPANHIA_INFO } from '../data';

export default function Footer() {
  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const handleScrollTo = (targetId: string) => {
    const element = document.getElementById(targetId);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer
      className="bg-[#050505] text-brand-beige border-t border-brand-gold/15 relative font-sans"
      id="rodape-secao"
    >
      {/* Footer grid block */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-10 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-16 border-b border-brand-gold/15">
          
          {/* Column 1: Branding block information (4 cols on lg and up) */}
          <div className="lg:col-span-4 flex flex-col space-y-6">
            <div
              className="flex items-center gap-2 cursor-pointer self-start"
              onClick={handleScrollToTop}
              id="footer-logo"
            >
              <div className="w-9 h-9 bg-brand-gold rounded-xl flex items-center justify-center shadow-md">
                <Leaf className="w-5 h-5 text-black" />
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-lg font-bold tracking-wide text-white">
                  Aura
                </span>
                <span className="text-[9px] font-mono tracking-widest text-brand-gold/90 leading-none uppercase font-bold">
                  Arquitetura Sustentável
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-brand-beige/70 leading-relaxed font-light">
              Projetando arquiteturas ecológicas que curam corpos e acalmam mentes. Combinamos sofisticação de alto padrão de engenharia com as leis primárias da natureza.
            </p>

            {/* Social media connections */}
            <div className="flex gap-3">
              <a
                href={COMPANHIA_INFO.redesSociais.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-brand-gold border border-brand-gold/15 flex items-center justify-center text-white hover:text-black hover:scale-105 transition-all"
                aria-label="Aura Instagram"
              >
                <Instagram className="w-4.5 h-4.5" />
              </a>
              <a
                href={COMPANHIA_INFO.redesSociais.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-brand-gold border border-brand-gold/15 flex items-center justify-center text-white hover:text-black hover:scale-105 transition-all"
                aria-label="Aura LinkedIn"
              >
                <Linkedin className="w-4.5 h-4.5" />
              </a>
              <a
                href={COMPANHIA_INFO.redesSociais.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-brand-gold border border-brand-gold/15 flex items-center justify-center text-white hover:text-black hover:scale-105 transition-all"
                aria-label="Aura YouTube"
              >
                <Youtube className="w-4.5 h-4.5" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links (3 cols on lg and up) */}
          <div className="lg:col-span-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-[#C5A16F] mb-6">
              Navegação Rápida
            </h4>
            <ul className="space-y-3 text-xs sm:text-sm font-light text-brand-beige/85">
              <li>
                <button
                  onClick={() => handleScrollTo('inicio')}
                  className="hover:text-brand-gold cursor-pointer transition-colors"
                >
                  Página Inicial (Início)
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleScrollTo('sobre')}
                  className="hover:text-brand-gold cursor-pointer transition-colors"
                >
                  Sobre Nós (História)
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleScrollTo('servicos')}
                  className="hover:text-brand-gold cursor-pointer transition-colors"
                >
                  Nossos Serviços e Produtos
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleScrollTo('galeria')}
                  className="hover:text-brand-gold cursor-pointer transition-colors"
                >
                  Galeria de Projetos
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleScrollTo('faq')}
                  className="hover:text-brand-gold cursor-pointer transition-colors"
                >
                  Dúvidas Frequentes (FAQ)
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleScrollTo('contato')}
                  className="hover:text-brand-gold cursor-pointer transition-colors"
                >
                  Contato & Consultoria
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Contact & address details (5 cols on lg and up) */}
          <div className="lg:col-span-5 flex flex-col space-y-6">
            <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-[#C5A16F] mb-1">
              Contato Sede Central
            </h4>
            
            <div className="space-y-4 text-xs sm:text-sm font-light text-brand-beige/80">
              <div className="flex gap-3 items-start">
                <MapPin className="w-4.5 h-4.5 text-brand-gold shrink-0 mt-0.5" />
                <span>{COMPANHIA_INFO.endereco}</span>
              </div>
              <div className="flex gap-3 items-center">
                <Phone className="w-4.5 h-4.5 text-brand-gold shrink-0" />
                <span className="font-mono">{COMPANHIA_INFO.telefone}</span>
              </div>
              <div className="flex gap-3 items-center">
                <Mail className="w-4.5 h-4.5 text-brand-gold shrink-0" />
                <span className="font-mono">{COMPANHIA_INFO.email}</span>
              </div>
              <div className="flex gap-3 items-center">
                <Calendar className="w-4.5 h-4.5 text-brand-gold shrink-0" />
                <span>{COMPANHIA_INFO.funcionamento}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom copyright row with scroll back up trigger */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-mono text-brand-beige/60">
          <p className="text-center sm:text-left">
            © {currentYear} {COMPANHIA_INFO.nome}. Todos os direitos reservados. Fictional project.
          </p>
          
          <button
            onClick={handleScrollToTop}
            className="flex items-center gap-2 group text-[11px] font-bold text-brand-gold hover:text-white transition-colors cursor-pointer"
            id="btn-scroll-top-footer"
            title="Voltar ao início"
          >
            <span>Voltar ao Topo</span>
            <div className="w-7 h-7 bg-white/5 border border-brand-gold/25 rounded-lg flex items-center justify-center transition-all group-hover:bg-brand-gold group-hover:text-black">
              <ArrowUp className="w-3.5 h-3.5" />
            </div>
          </button>
        </div>

      </div>
    </footer>
  );
}
