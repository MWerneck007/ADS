/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Menu, X, Leaf, PhoneCall } from 'lucide-react';
import { COMPANHIA_INFO } from '../data';

interface NavbarProps {
  activeSection: string;
}

export default function Navbar({ activeSection }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'Início', target: 'inicio' },
    { label: 'Sobre', target: 'sobre' },
    { label: 'Serviços', target: 'servicos' },
    { label: 'Escolha', target: 'diferenciais' },
    { label: 'Galeria', target: 'galeria' },
    { label: 'Equipe', target: 'equipe' },
    { label: 'Depoimentos', target: 'depoimentos' },
    { label: 'FAQ', target: 'faq' },
    { label: 'Contato', target: 'contato' }
  ];

  const handleScrollTo = (targetId: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(targetId);
    if (element) {
      const offset = 80; // height of fixed navbar
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <>
      <header
        id="navbar-header"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-brand-beige/95 backdrop-blur-md shadow-md border-b border-brand-gold/10 py-3'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo and Branding */}
            <div
              className="flex items-center gap-2 cursor-pointer group"
              onClick={() => handleScrollTo('inicio')}
              id="brand-logo"
            >
              <div className="w-10 h-10 bg-brand-emerald-dark rounded-xl flex items-center justify-center transition-all duration-300 group-hover:bg-brand-emerald-medium shadow-md">
                <Leaf className="w-5 h-5 text-brand-gold transition-transform duration-500 group-hover:rotate-12" />
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-lg font-bold tracking-wide text-brand-emerald-dark">
                  {COMPANHIA_INFO.nome.split(' ')[0]}
                </span>
                <span className="text-[10px] font-mono tracking-widest text-[#9D8466] leading-none uppercase">
                  Arquitetura
                </span>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-2" id="desktop-nav">
              {menuItems.map((item) => (
                <button
                  key={item.target}
                  onClick={() => handleScrollTo(item.target)}
                  className={`px-3 py-2 text-xs xl:text-sm font-medium rounded-lg transition-all duration-200 cursor-pointer ${
                    activeSection === item.target
                      ? 'text-brand-gold bg-brand-gold/15 font-semibold'
                      : 'text-brand-charcoal hover:text-white hover:bg-brand-gold/5'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Action CTA Button */}
            <div className="hidden sm:flex items-center gap-4">
              <button
                onClick={() => handleScrollTo('contato')}
                className="flex items-center gap-2 px-5 py-2.5 bg-brand-emerald-dark hover:bg-brand-emerald-medium text-brand-beige font-medium text-xs xl:text-sm rounded-xl transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg cursor-pointer"
                id="btn-nav-contato"
              >
                <PhoneCall className="w-4 h-4 text-brand-gold" />
                <span>Falar Conosco</span>
              </button>
            </div>

            {/* Mobile Menu Open Toggle */}
            <div className="lg:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 text-brand-emerald-dark hover:bg-brand-gold/10 rounded-lg transition-colors cursor-pointer"
                aria-label="Toggle menu"
                id="mobile-menu-toggle"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation overlay */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-brand-emerald-dark/60 backdrop-blur-sm lg:hidden transition-opacity"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      <div
        className={`fixed top-0 right-0 bottom-0 z-40 w-80 max-w-full bg-[#121212] border-l border-brand-gold/20 shadow-2xl lg:hidden flex flex-col p-6 transition-transform duration-300 transform ${
          isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between border-b border-brand-gold/20 pb-5 mb-6 mt-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-[#1a1a1a] rounded-lg flex items-center justify-center border border-brand-gold/15">
              <Leaf className="w-4 h-4 text-brand-gold" />
            </div>
            <span className="font-serif text-md font-bold tracking-wide text-brand-gold italic">
              Aura Arquitetura
            </span>
          </div>
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="p-2 text-brand-charcoal bg-brand-gold/10 rounded-lg hover:bg-brand-gold/20"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex flex-col gap-2 overflow-y-auto flex-1 pr-1">
          {menuItems.map((item) => (
            <button
              key={item.target}
              onClick={() => handleScrollTo(item.target)}
              className={`w-full text-left px-4 py-3 rounded-xl transition-all duration-200 text-sm font-medium ${
                activeSection === item.target
                  ? 'bg-brand-gold/10 text-brand-gold border-l-4 border-brand-gold font-semibold'
                  : 'text-brand-charcoal hover:bg-brand-gold/5'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="border-t border-brand-gold/20 pt-6 mt-auto">
          <button
            onClick={() => handleScrollTo('contato')}
            className="w-full flex items-center justify-center gap-2 px-5 py-3.5 bg-brand-emerald-dark hover:bg-brand-emerald-medium text-brand-beige font-semibold text-sm rounded-xl transition-colors shadow-lg"
          >
            <PhoneCall className="w-4 h-4 text-brand-gold" />
            <span>Fazer um Orçamento</span>
          </button>
          <div className="text-center mt-4">
            <span className="text-[10px] font-mono text-brand-charcoal/50">
              {COMPANHIA_INFO.telefone}
            </span>
          </div>
        </div>
      </div>
    </>
  );
}
