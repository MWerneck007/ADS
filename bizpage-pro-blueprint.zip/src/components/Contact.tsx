/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Send, CheckCircle2, Phone, Mail, AlertTriangle, ArrowRight, ShieldCheck } from 'lucide-react';
import { COMPANHIA_INFO, SERVICOS } from '../data';

export default function Contact() {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    servico: 'serv-residencial',
    mensagem: '',
    termos: false
  });

  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });

    // Clear specific error on change
    if (formErrors[name]) {
      const updatedErrors = { ...formErrors };
      delete updatedErrors[name];
      setFormErrors(updatedErrors);
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      termos: e.target.checked
    });
    if (formErrors.termos) {
      const updatedErrors = { ...formErrors };
      delete updatedErrors.termos;
      setFormErrors(updatedErrors);
    }
  };

  const validateForm = () => {
    const errors: { [key: string]: string } = {};

    if (!formData.nome.trim()) {
      errors.nome = 'Por favor, informe seu nome completo.';
    } else if (formData.nome.trim().length < 3) {
      errors.nome = 'O nome deve ter no mínimo 3 caracteres.';
    }

    if (!formData.email.trim()) {
      errors.email = 'O e-mail é obrigatório.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Insira um endereço de e-mail válido.';
    }

    if (!formData.telefone.trim()) {
      errors.telefone = 'Por favor, informe seu telefone.';
    } else if (!/^\(?\d{2}\)?\s?\d{4,5}-?\d{4}$/.test(formData.telefone.replace(/\s/g, ''))) {
      errors.telefone = 'Insira um telefone/celular válido com DDD.';
    }

    if (!formData.mensagem.trim()) {
      errors.mensagem = 'Escreva uma mensagem detalhando o seu sonho ou projeto.';
    } else if (formData.mensagem.trim().length < 10) {
      errors.mensagem = 'A mensagem deve conter pelo menos 10 caracteres.';
    }

    if (!formData.termos) {
      errors.termos = 'Você precisa aceitar os termos de privacidade para continuar.';
    }

    return errors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors = validateForm();

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setIsSubmitting(true);

    // Simulate async network call to local server proxy
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      // Reset form fields
      setFormData({
        nome: '',
        email: '',
        telefone: '',
        servico: 'serv-residencial',
        mensagem: '',
        termos: false
      });
    }, 1500);
  };

  return (
    <section
      id="contato"
      className="py-24 bg-[#0a0a0a] relative overflow-hidden font-sans"
    >
      {/* Decorative Blur Background circles */}
      <div className="absolute -bottom-24 -left-20 w-80 h-80 bg-brand-gold/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-brand-gold uppercase">
            Inicie Seu Projeto
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mt-2 mb-4">
            Dê vida ao seu Refúgio Ecológico
          </h2>
          <p className="text-sm sm:text-base text-brand-charcoal/80 leading-relaxed font-light">
            Solicite um orçamento preliminar ou agende uma reunião presencial. Retornamos o contato em até 24 horas úteis.
          </p>
          <div className="w-16 h-1 bg-brand-gold mx-auto mt-4 rounded-full" />
        </div>

        {/* Cohesive Content columns */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Form Block */}
          <div className="lg:col-span-7 bg-[#121212] rounded-3xl p-6 sm:p-10 shadow-2xl border border-brand-gold/15">
            {isSubmitted ? (
              /* Success Submission Block */
              <div
                className="text-center py-12 px-4 flex flex-col items-center"
                id="contact-success-banner"
              >
                <div className="w-20 h-20 bg-brand-gold/10 rounded-full flex items-center justify-center text-brand-gold mb-6 border border-brand-gold/20">
                  <CheckCircle2 className="w-10 h-10 text-brand-gold" />
                </div>
                <h3 className="text-2xl font-serif font-bold text-white mb-3">
                  Mensagem Enviada com Sucesso!
                </h3>
                <p className="text-brand-charcoal/80 text-sm max-w-md mx-auto leading-relaxed font-light mb-8">
                  Agradecemos o seu contato. Um de nossos arquitetos especialistas em design biofílico analisará seus requisitos e telefonará para você o mais breve possível.
                </p>
                <button
                  onClick={() => setIsSubmitted(false)}
                  className="px-6 py-2.5 bg-brand-gold hover:bg-[#a38051] text-black text-xs font-bold rounded-xl transition-all cursor-pointer shadow-md"
                >
                  Enviar Outra Mensagem
                </button>
              </div>
            ) : (
              /* Form Component itself */
              <form onSubmit={handleSubmit} className="space-y-6" id="contact-form">
                
                {/* Form Group: Nome & Telefone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {/* Nome */}
                  <div>
                    <label htmlFor="nome" className="block text-xs font-mono font-bold uppercase tracking-wider text-brand-gold mb-2">
                      Nome Completo *
                    </label>
                    <input
                      type="text"
                      id="nome"
                      name="nome"
                      placeholder="Ex: Amanda Silva"
                      value={formData.nome}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 bg-[#161616] border rounded-xl text-sm outline-none text-white transition-all placeholder:text-neutral-600 ${
                        formErrors.nome
                          ? 'border-red-500 ring-1 ring-red-500 bg-red-500/5'
                          : 'border-brand-gold/20 focus:border-brand-gold focus:ring-1 focus:ring-brand-gold'
                      }`}
                    />
                    {formErrors.nome && (
                      <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>{formErrors.nome}</span>
                      </p>
                    )}
                  </div>

                  {/* Telefone */}
                  <div>
                    <label htmlFor="telefone" className="block text-xs font-mono font-bold uppercase tracking-wider text-brand-gold mb-2">
                      Telefone com DDD *
                    </label>
                    <input
                      type="tel"
                      id="telefone"
                      name="telefone"
                      placeholder="Ex: (11) 98765-4321"
                      value={formData.telefone}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 bg-[#161616] border rounded-xl text-sm outline-none text-white transition-all placeholder:text-neutral-600 ${
                        formErrors.telefone
                          ? 'border-red-500 ring-1 ring-red-500 bg-red-505/5'
                          : 'border-brand-gold/20 focus:border-brand-gold focus:ring-1 focus:ring-brand-gold'
                      }`}
                    />
                    {formErrors.telefone && (
                      <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>{formErrors.telefone}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Form Group: Email & Servico */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {/* Email */}
                  <div>
                    <label htmlFor="email" className="block text-xs font-mono font-bold uppercase tracking-wider text-brand-gold mb-2">
                      E-mail Principal *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      placeholder="Ex: amanda@exemplo.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 bg-[#161616] border rounded-xl text-sm outline-none text-white transition-all placeholder:text-neutral-600 ${
                        formErrors.email
                          ? 'border-red-500 ring-1 ring-red-500 bg-red-500/5'
                          : 'border-brand-gold/20 focus:border-brand-gold focus:ring-1 focus:ring-brand-gold'
                      }`}
                    />
                    {formErrors.email && (
                      <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>{formErrors.email}</span>
                      </p>
                    )}
                  </div>

                  {/* Servico interesse */}
                  <div>
                    <label htmlFor="servico" className="block text-xs font-mono font-bold uppercase tracking-wider text-brand-gold mb-2">
                       Serviço de Interesse *
                    </label>
                    <select
                      id="servico"
                      name="servico"
                      value={formData.servico}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 bg-[#161616] border border-brand-gold/20 focus:border-brand-gold focus:ring-1 focus:ring-brand-gold rounded-xl text-sm text-white outline-none font-light cursor-pointer"
                    >
                      {SERVICOS.map((serv) => (
                        <option key={serv.id} value={serv.id} className="bg-[#161616] text-white">
                          {serv.title}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Mensagem text area */}
                <div>
                  <label htmlFor="mensagem" className="block text-xs font-mono font-bold uppercase tracking-wider text-brand-gold mb-2">
                    Detalhes do seu Projeto *
                  </label>
                  <textarea
                    id="mensagem"
                    name="mensagem"
                    rows={4}
                    placeholder="Nos conte sobre seu terreno, objetivos do espaço e o que você gostaria de construir..."
                    value={formData.mensagem}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 bg-[#161616] border rounded-xl text-sm outline-none h-32 resize-none text-white transition-all placeholder:text-neutral-600 ${
                      formErrors.mensagem
                        ? 'border-red-500 ring-1 ring-red-500 bg-red-500/5'
                        : 'border-brand-gold/20 focus:border-brand-gold focus:ring-1 focus:ring-brand-gold'
                    }`}
                  />
                  {formErrors.mensagem && (
                    <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>{formErrors.mensagem}</span>
                    </p>
                  )}
                </div>

                {/* Terms Acceptance switch */}
                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="termos"
                    checked={formData.termos}
                    onChange={handleCheckboxChange}
                    className="w-4.5 h-4.5 accent-brand-gold cursor-pointer shrink-0 mt-0.5 rounded border border-brand-gold/20"
                  />
                  <div className="flex-1">
                    <label htmlFor="termos" className="block text-xs text-brand-charcoal/85 leading-relaxed font-light cursor-pointer">
                      Aceito que os dados transmitidos no formulário acima sejam tratados pela equipe da Aura Arquitetura conforme as diretrizes da LGPD vigentes. *
                    </label>
                    {formErrors.termos && (
                      <p className="text-red-500 text-[11px] mt-1 flex items-center gap-1 font-semibold">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>{formErrors.termos}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Submit button wrapper */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full flex items-center justify-center gap-2 py-4 bg-brand-gold hover:bg-[#a38051] text-black font-semibold rounded-xl transition-all shadow-md hover:shadow-lg focus:outline-none cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                        <span>Enviando dados...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 text-black" />
                        <span>Enviar Solicitação</span>
                      </>
                    )}
                  </button>
                </div>

              </form>
            )}
          </div>

          {/* Right Column: High-end information / design pipeline cards */}
          <div className="lg:col-span-5 flex flex-col justify-between h-full space-y-8">
            
            {/* Quick Contact info */}
            <div className="bg-[#121212] text-brand-charcoal p-8 rounded-3xl border border-brand-gold/20 relative overflow-hidden shadow-2xl" id="quick-connect">
              <div className="absolute inset-0 bg-[radial-gradient(#C5A16F_0.5px,transparent_0.5px)] [background-size:20px_20px] opacity-10" />
              
              <h3 className="text-xl font-serif font-bold text-white mb-4 relative z-10">
                Suporte Direto Aura
              </h3>
              <p className="text-xs text-brand-charcoal/80 leading-relaxed font-light mb-6 relative z-10">
                Caso tenha preferência por entrar em contato de forma direta, use nossos canais telefônicos e e-mails abaixo para atendimento imediato:
              </p>

              <div className="space-y-4 relative z-10 text-white">
                <div className="flex items-center gap-3">
                  <Phone className="w-4.5 h-4.5 text-brand-gold" />
                  <span className="text-xs sm:text-sm font-mono tracking-wide">{COMPANHIA_INFO.telefone}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="w-4.5 h-4.5 text-brand-gold" />
                  <span className="text-xs sm:text-sm font-mono tracking-wide font-light">{COMPANHIA_INFO.email}</span>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-brand-gold/25 text-[11px] font-mono text-brand-gold uppercase tracking-wider font-bold">
                * Atendimento exclusivo das 09h às 18h
              </div>
            </div>

            {/* Pipeline Step Card */}
            <div className="p-8 bg-[#121212] border border-brand-gold/15 rounded-3xl shadow-xl relative" id="design-pipeline">
              <span className="text-[10px] font-mono font-bold text-[#9D8466] uppercase tracking-wider block mb-2">
                NOSSA PIPELINE CONSTRUTIVA
              </span>
              <h3 className="text-lg font-serif font-semibold text-white mb-5">
                Como funciona o processo?
              </h3>

              <div className="space-y-5">
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-brand-gold text-black flex items-center justify-center font-mono text-xs font-bold shrink-0 shadow-md">
                    1
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-brand-gold">Entrevista Preliminar</h4>
                    <p className="text-[11px] text-brand-charcoal/70 leading-relaxed font-light mt-0.5">Analizamos de forma consultiva suas aspirações, uso familiar e o terreno em uma conversa de 30min.</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-brand-gold text-black flex items-center justify-center font-mono text-xs font-bold shrink-0 shadow-md">
                    2
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-brand-gold">Estudo de Climatização e Solo</h4>
                    <p className="text-[11px] text-brand-charcoal/70 leading-relaxed font-light mt-0.5">Nossa equipe botânica estuda a insolação solar, bacia hídrica e ventos locais antes da primeira linha de design.</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-brand-gold text-black flex items-center justify-center font-mono text-xs font-bold shrink-0 shadow-md">
                    3
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-brand-gold">Maquete 3D Interativa</h4>
                    <p className="text-[11px] text-brand-charcoal/70 leading-relaxed font-light mt-0.5">Apresentamos uma renderização completa imersiva para que você refine detalhes com nossos diretores.</p>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-5 border-t border-brand-gold/15 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-brand-gold" />
                <span className="text-[10px] text-brand-charcoal/60 leading-none">Satisfação e acompanhamento estrito garantido de ponta a ponta.</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
