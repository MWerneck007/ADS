/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { METRICAS } from '../data';

export default function Stats() {
  return (
    <section className="relative py-16 bg-brand-emerald-dark overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-x-0 bottom-0 top-0 bg-[radial-gradient(#C5A16F_0.5px,transparent_0.5px)] [background-size:24px_24px] opacity-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-4 divide-y md:divide-y-0 md:divide-x divide-brand-gold/20">
          {METRICAS.map((stat, i) => (
            <div
              key={i}
              className="flex flex-col items-center text-center p-4 first:pt-4 md:first:pt-4 pt-8 md:pt-4"
            >
              <div className="flex items-baseline text-white">
                <span className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold tracking-tight">
                  {stat.number}
                </span>
                {stat.suffix && (
                  <span className="text-brand-gold text-2xl sm:text-3xl font-semibold ml-0.5">
                    {stat.suffix}
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm font-mono tracking-widest text-brand-gold/90 font-medium uppercase mt-3">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
