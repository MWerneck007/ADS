/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Leaf, Trees, Cpu, Sparkles, Trophy, Eye, Target } from 'lucide-react';
import { COMPANHIA_INFO, VALORES } from '../data';

const iconMap: { [key: string]: React.ComponentType<any> } = {
  Leaf: Leaf,
  Trees: Trees,
  Cpu: Cpu,
  Sparkles: Sparkles
};

export default function About() {
  return (
    <section
      id="sobre"
      className="py-24 bg-[#0a0a0a] relative overflow-hidden"
    >
      {/* Decorative vertical golden stripes */}
      <div className="absolute right-0 top-0 bottom-0 w-1 bg-gradient-to-b from-brand-gold/0 via-brand-gold/15 to-brand-gold/0 pointer-events-none hidden md:block" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 font-sans">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-brand-gold uppercase">
            Nossa Essência
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mt-2 mb-4">
            Sobre a Aura Arquitetura
          </h2>
          <p className="text-sm sm:text-base text-brand-charcoal/80 leading-relaxed font-light">
            Alinhando tecnologia, botânica arquitetônica e luxo consciente para desenhar os refúgios do futuro.
          </p>
          <div className="w-16 h-1 bg-brand-gold mx-auto mt-4 rounded-full" />
        </div>

        {/* Cohesive Grid block */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Brief History */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="text-xl sm:text-2xl font-serif font-bold text-brand-gold">
              Como tudo começou: Nossa História
            </h3>
            
            <p className="text-brand-charcoal/90 text-sm sm:text-base leading-relaxed font-light">
              {COMPANHIA_INFO.historia}
            </p>

            {/* Injected Statement Quote */}
            <div className="border-l-4 border-brand-gold pl-4 py-2 my-6 bg-white/5 rounded-r-xl">
              <p className="italic text-brand-gold text-sm sm:text-md">
                "Casas não devem apenas nos abrigar do mundo; elas devem nos reconectar biologicamente com a energia regenerativa que nos sustenta."
              </p>
              <cite className="block text-xs font-mono text-brand-charcoal/60 mt-2 font-bold uppercase not-italic">
                — Sofia Alencar, Fundadora
              </cite>
            </div>

            {/* Mission & Vision Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8">
              {/* Mission */}
              <div className="bg-white/5 p-6 rounded-2xl border border-brand-gold/10 hover:border-brand-gold/30 transition-all">
                <div className="w-10 h-10 bg-brand-gold/10 rounded-xl flex items-center justify-center text-brand-gold mb-4">
                  <Target className="w-5 h-5 text-brand-gold" />
                </div>
                <h4 className="text-md font-serif font-bold text-white mb-2">
                  Nossa Missão
                </h4>
                <p className="text-xs sm:text-sm text-brand-charcoal/80 leading-relaxed font-light">
                  {COMPANHIA_INFO.missao}
                </p>
              </div>

              {/* Vision */}
              <div className="bg-white/5 p-6 rounded-2xl border border-brand-gold/10 hover:border-brand-gold/30 transition-all">
                <div className="w-10 h-10 bg-brand-gold/10 rounded-xl flex items-center justify-center text-brand-gold mb-4">
                  <Eye className="w-5 h-5 text-brand-gold" />
                </div>
                <h4 className="text-md font-serif font-bold text-white mb-2">
                  Nossa Visão
                </h4>
                <p className="text-xs sm:text-sm text-brand-charcoal/80 leading-relaxed font-light">
                  {COMPANHIA_INFO.visao}
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Values & Visual Accent Card */}
          <div className="lg:col-span-5 bg-brand-emerald-dark text-brand-charcoal p-8 rounded-2xl relative overflow-hidden shadow-2xl border border-brand-gold/20">
            {/* Background pattern mask */}
            <div className="absolute inset-0 bg-[radial-gradient(#c5a059_0.8px,transparent_0.8px)] [background-size:16px_16px] opacity-5" />
            
            <span className="text-[10px] font-mono tracking-widest text-brand-gold uppercase font-bold block mb-2">
              PILARES FUNDAMENTAIS
            </span>
            <h3 className="text-xl sm:text-2xl font-serif font-semibold text-white mb-6">
              Nossos Valores
            </h3>

            <div className="space-y-6 relative z-10" id="values-list">
              {VALORES.map((val, index) => {
                const IconComponent = iconMap[val.iconName] || Sparkles;
                return (
                  <div
                    key={index}
                    className="flex gap-4 items-start"
                  >
                    <div className="mt-1 w-10 h-10 bg-brand-gold/10 border border-brand-gold/15 hover:bg-brand-gold/20 rounded-xl flex items-center justify-center text-brand-gold transition-colors shrink-0">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold tracking-wide text-brand-gold">
                        {val.title}
                      </h4>
                      <p className="text-xs text-brand-charcoal/80 leading-relaxed font-light mt-1">
                        {val.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-8 pt-6 border-t border-brand-gold/20 flex items-center gap-3">
              <span className="text-[11px] font-mono text-brand-gold/80 uppercase tracking-widest leading-none font-bold">
                Arquitetura que cura
              </span>
              <div className="flex-1 h-[1px] bg-brand-gold/20" />
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
