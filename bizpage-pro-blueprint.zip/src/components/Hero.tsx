/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { COMPANHIA_INFO } from '../data';
import { motion } from 'motion/react';

export default function Hero() {
  const handleScrollToContact = () => {
    const contactSection = document.getElementById('contato');
    if (contactSection) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elemRect = contactSection.getBoundingClientRect().top;
      const elemPos = elemRect - bodyRect;
      const offsetPos = elemPos - offset;
      window.scrollTo({
        top: offsetPos,
        behavior: 'smooth'
      });
    }
  };

  const handleScrollToServices = () => {
    const servicesSection = document.getElementById('servicos');
    if (servicesSection) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elemRect = servicesSection.getBoundingClientRect().top;
      const elemPos = elemRect - bodyRect;
      const offsetPos = elemPos - offset;
      window.scrollTo({
        top: offsetPos,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section
      id="inicio"
      className="relative min-h-[95vh] lg:min-h-screen pt-28 pb-16 flex items-center overflow-hidden bg-gradient-to-b from-[#0e0e0e] via-brand-beige to-[#0a0a0a]"
    >
      {/* Dynamic Background Accents */}
      <div className="absolute top-1/4 -left-36 w-96 h-96 bg-brand-emerald-medium/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-36 w-96 h-96 bg-brand-gold/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative w-full h-full z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Text Left Column (7 Grid Columns on big displays) */}
          <div className="lg:col-span-7 flex flex-col justify-center text-center lg:text-left">
            {/* Tagline Indicator badge */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 self-center lg:self-start bg-brand-gold/10 border border-brand-gold/25 text-brand-gold px-4 py-1.5 rounded-full text-xs font-mono font-semibold tracking-wider uppercase mb-6"
              id="hero-badge"
            >
              <Sparkles className="w-3.5 h-3.5 text-brand-gold animate-pulse" />
              <span>Sustentabilidade &amp; Sofisticação</span>
            </motion.div>

            {/* Slogan Title */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-4xl sm:text-5xl md:text-6xl font-serif font-bold text-white leading-tight tracking-tight mb-6"
              id="hero-slogan"
            >
              {COMPANHIA_INFO.slogan}
            </motion.h1>

            {/* Subtitle Description */}
            <motion.p
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-base sm:text-lg md:text-xl text-brand-charcoal/90 leading-relaxed mb-10 max-w-2xl mx-auto lg:mx-0 font-light"
              id="hero-subtitulo"
            >
              {COMPANHIA_INFO.subtitulo}
            </motion.p>

            {/* Action CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start"
              id="hero-actions"
            >
              <button
                onClick={handleScrollToContact}
                className="w-full sm:w-auto px-8 py-4 bg-brand-gold hover:bg-[#a38051] text-black font-semibold rounded-xl transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-brand-gold/20 flex items-center justify-center gap-2 cursor-pointer group"
              >
                <span>Solicite um Orçamento</span>
                <ArrowRight className="w-4 h-4 text-black transition-transform duration-300 group-hover:translate-x-1" />
              </button>
              <button
                onClick={handleScrollToServices}
                className="w-full sm:w-auto px-8 py-4 bg-white/5 backdrop-blur-sm hover:bg-white/10 text-white font-semibold rounded-xl border border-brand-gold/30 hover:border-brand-gold transition-all duration-300 transform hover:-translate-y-1 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Conhecer Serviços</span>
              </button>
            </motion.div>

            {/* Small reassurance statements */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="flex flex-wrap items-center justify-center lg:justify-start gap-x-6 gap-y-3 mt-10 text-brand-charcoal/70 text-xs font-medium"
              id="hero-trust"
            >
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-brand-gold" />
                <span>Zero Carbono</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-brand-gold" />
                <span>Arquitetos Registrados</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-brand-gold" />
                <span>Projetos de Luxo WELL &amp; LEED</span>
              </div>
            </motion.div>
          </div>

          {/* Render Visual Right Frame (5 Grid Columns) */}
          <div className="lg:col-span-5 relative flex justify-center items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="relative w-full aspect-[4/5] sm:aspect-square lg:aspect-[4/5] max-w-[450px] rounded-2xl overflow-hidden shadow-2xl group border-4 border-brand-gold/20"
              id="hero-image-wrapper"
            >
              <img
                src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=800&auto=format&fit=crop"
                alt="Arquitetura Biofílica Aura"
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-beige via-transparent to-transparent opacity-60 pointer-events-none" />

              {/* Floater metrics block inside image overlay */}
              <div className="absolute bottom-6 left-6 right-6 bg-[#121212]/90 backdrop-blur-md p-4 rounded-xl border border-brand-gold/15 shadow-xl flex items-center gap-3">
                <div className="w-12 h-12 bg-[#1a1a1a] border border-brand-gold/25 rounded-lg flex items-center justify-center text-brand-gold font-bold text-lg font-serif">
                  A
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-brand-gold">Casas em Perfeita Sintonia</h4>
                  <p className="text-[11px] text-brand-charcoal/80 leading-tight">Projetos residenciais ecológicos de alta sofisticação arquitetônica.</p>
                </div>
              </div>
            </motion.div>

            {/* Framing background visual line */}
            <div className="absolute -inset-4 border border-brand-gold/20 rounded-3xl -z-10 transform rotate-2 pointer-events-none" />
          </div>
        </div>
      </div>
    </section>
  );
}
