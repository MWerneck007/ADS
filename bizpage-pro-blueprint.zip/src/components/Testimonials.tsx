/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DEPOIMENTOS } from '../data';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';

export default function Testimonials() {
  const [activeIndex, setActiveIndex] = useState(0);

  const nextTestimonial = () => {
    setActiveIndex((activeIndex + 1) % DEPOIMENTOS.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((activeIndex - 1 + DEPOIMENTOS.length) % DEPOIMENTOS.length);
  };

  return (
    <section
      id="depoimentos"
      className="py-24 bg-[#0a0a0a] relative overflow-hidden"
    >
      <div className="absolute top-24 left-10 text-brand-gold/5 pointer-events-none hidden lg:block">
        <Quote className="w-48 h-48 transform -rotate-12" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 font-sans">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-brand-gold uppercase">
            Satisfeitos e Integrados
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mt-2 mb-4">
            Depoimentos de Nossos Clientes
          </h2>
          <p className="text-sm sm:text-base text-brand-charcoal/80 leading-relaxed font-light">
            Descubra as histórias de quem transformou sua relação com o bem-estar e o hábito cotidiano ao vivenciar o design biofílico da Aura.
          </p>
          <div className="w-16 h-1 bg-brand-gold mx-auto mt-4 rounded-full" />
        </div>

        {/* Dynamic Carousel Slide Panel */}
        <div className="relative bg-[#121212]/90 border border-brand-gold/15 rounded-3xl p-6 sm:p-10 shadow-2xl max-w-4xl mx-auto">
          {/* Quote layout block */}
          <div className="flex flex-col md:flex-row gap-8 items-center md:items-start text-center md:text-left">
            
            {/* Customer picture frame */}
            <div className="relative shrink-0">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden border-4 border-brand-gold/25 shadow-lg">
                <img
                  src={DEPOIMENTOS[activeIndex].imageUrl}
                  alt={DEPOIMENTOS[activeIndex].name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              {/* Quote Mark Mini Badge */}
              <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-brand-gold flex items-center justify-center text-black border-2 border-[#121212] shadow-md">
                <Quote className="w-3.5 h-3.5 fill-current" />
              </div>
            </div>

            {/* Testimonial body content */}
            <div className="flex-1 flex flex-col justify-between h-full">
              <div>
                {/* Rating Stars render */}
                <div className="flex items-center gap-1 justify-center md:justify-start mb-4">
                  {[...Array(DEPOIMENTOS[activeIndex].rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-brand-gold text-brand-gold" />
                  ))}
                </div>

                <p className="text-brand-charcoal/90 text-sm sm:text-base font-light italic leading-relaxed mb-6">
                  "{DEPOIMENTOS[activeIndex].text}"
                </p>
              </div>

              {/* Author profile tag */}
              <div className="border-t border-brand-gold/10 pt-4 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div>
                  <h4 className="text-sm sm:text-base font-bold text-white">
                    {DEPOIMENTOS[activeIndex].name}
                  </h4>
                  <p className="text-xs text-[#9D8466] font-mono mt-0.5">
                    {DEPOIMENTOS[activeIndex].role} • {DEPOIMENTOS[activeIndex].company}
                  </p>
                </div>

                {/* Left/Right controls inside card */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={prevTestimonial}
                    className="p-2 sm:p-2.5 rounded-xl border border-brand-gold/20 bg-white/5 hover:bg-brand-gold text-brand-gold hover:text-black hover:border-brand-gold cursor-pointer transition-all duration-300 shadow-sm"
                    aria-label="Depoimento anterior"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={nextTestimonial}
                    className="p-2 sm:p-2.5 rounded-xl border border-brand-gold/20 bg-white/5 hover:bg-brand-gold text-brand-gold hover:text-black hover:border-brand-gold cursor-pointer transition-all duration-300 shadow-sm"
                    aria-label="Próximo depoimento"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </div>

          </div>
        </div>

        {/* Indicator dots navigation */}
        <div className="flex justify-center items-center gap-2 mt-8">
          {DEPOIMENTOS.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setActiveIndex(idx)}
              className={`h-2 rounded-full cursor-pointer transition-all duration-300 ${
                activeIndex === idx ? 'w-8 bg-brand-gold shadow-md' : 'w-2 bg-brand-gold/30 hover:bg-brand-gold'
              }`}
              aria-label={`Ir para depoimento ${idx + 1}`}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
