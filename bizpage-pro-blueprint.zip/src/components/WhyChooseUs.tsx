/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Award, Wind, Activity, ShieldAlert, Check } from 'lucide-react';
import { DIFERENCIAIS } from '../data';

const iconMap: { [key: string]: React.ComponentType<any> } = {
  Award: Award,
  Wind: Wind,
  Activity: Activity,
  ShieldAlert: ShieldAlert
};

export default function WhyChooseUs() {
  return (
    <section
      id="diferenciais"
      className="py-24 bg-[#0a0a0a] relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 font-sans">
        
        {/* Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Premium Visuals */}
          <div className="lg:col-span- così lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-brand-gold/20" id="why-visual">
              <img
                src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=800&auto=format&fit=crop"
                alt="Detalhe de Arquitetura Verde"
                className="w-full aspect-[4/5] object-cover"
                referrerPolicy="no-referrer"
              />
              {/* Green overlay mask */}
              <div className="absolute inset-0 bg-gradient-to-t from-brand-beige to-transparent pointer-events-none" />
              
              {/* Floater overlay badge inside image */}
              <div className="absolute top-4 right-4 bg-brand-gold text-black font-mono text-[10px] font-bold uppercase tracking-wider py-1 px-3 rounded-full shadow-md">
                Tecnologia Pura
              </div>
            </div>

            {/* Backdrop styling border frame */}
            <div className="absolute -inset-4 border-2 border-dashed border-brand-gold/20 rounded-3xl -z-10 transform -rotate-2 pointer-events-none" />
          </div>

          {/* Right Column: Key Advantages */}
          <div className="lg:col-span-7">
            <span className="text-xs font-mono font-bold tracking-widest text-brand-gold uppercase">
              Nosso Compromisso
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mt-2 mb-6">
              Por que projetar com a Aura?
            </h2>
            <p className="text-brand-charcoal/80 text-sm sm:text-base leading-relaxed font-light mb-10">
              Não fazemos apenas construções sustentáveis genéricas; nós aplicamos metodologias fundamentais validadas cientificamente que integram engenharia regenerativa, neuroarquitetura sutil e beleza estética impecável.
            </p>

            {/* Key list */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6" id="diferenciais-grid">
              {DIFERENCIAIS.map((dif) => {
                const IconComponent = iconMap[dif.icon] || ShieldAlert;
                return (
                  <div
                    key={dif.id}
                    className="p-5 rounded-2xl bg-white/5 hover:bg-white/10 border border-brand-gold/10 hover:border-brand-gold/25 transition-all duration-300 group"
                  >
                    <div className="w-10 h-10 bg-brand-gold/10 group-hover:bg-brand-gold text-brand-gold group-hover:text-black rounded-xl flex items-center justify-center transition-colors duration-300 mb-4 shrink-0 shadow-sm">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <h3 className="text-sm font-bold tracking-wide text-brand-gold mb-1.5">
                      {dif.title}
                    </h3>
                    <p className="text-xs text-brand-charcoal/70 leading-relaxed font-light">
                      {dif.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
