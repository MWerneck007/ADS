/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Home, Building2, BatteryCharging, Sparkles, ChevronDown, ChevronUp, CheckCircle } from 'lucide-react';
import { SERVICOS } from '../data';

const iconMap: { [key: string]: React.ComponentType<any> } = {
  Home: Home,
  Building2: Building2,
  BatteryCharging: BatteryCharging,
  Flower: Sparkles // use sparkes, fits premium vibe perfectly
};

export default function Services() {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    if (expandedId === id) {
      setExpandedId(null);
    } else {
      setExpandedId(id);
    }
  };

  return (
    <section
      id="servicos"
      className="py-24 bg-[#0a0a0a] border-t border-b border-brand-gold/10"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 font-sans">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-brand-gold uppercase">
            Nosso Portfólio
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mt-2 mb-4">
            Produtos &amp; Serviços de Excelência
          </h2>
          <p className="text-sm sm:text-base text-brand-charcoal/80 leading-relaxed font-light">
            Concepção e modelagem cuidadosa de soluções ambientais premium integrando arquitetura sustentável aos seres humanos.
          </p>
          <div className="w-16 h-1 bg-brand-gold mx-auto mt-4 rounded-full" />
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {SERVICOS.map((serv) => {
            const IconComponent = iconMap[serv.iconName] || Sparkles;
            const isExpanded = expandedId === serv.id;

            return (
              <div
                key={serv.id}
                className="bg-[#121212]/85 rounded-3xl p-8 hover:bg-[#161616]/95 border border-brand-gold/15 hover:border-brand-gold/40 transition-all duration-300 flex flex-col justify-between group h-full shadow-2xl"
                id={`card-${serv.id}`}
              >
                <div>
                  {/* Card Header Profile */}
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-14 h-14 bg-[#1a1a1a] border border-brand-gold/20 text-brand-gold rounded-2xl flex items-center justify-center transition-transform duration-300 group-hover:scale-105 shadow-md">
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-[11px] font-mono font-bold text-brand-gold tracking-wide uppercase">
                        {serv.subtitle}
                      </span>
                      <h3 className="text-xl font-serif font-bold text-white">
                        {serv.title}
                      </h3>
                    </div>
                  </div>

                  {/* Description text */}
                  <p className="text-brand-charcoal/80 text-sm leading-relaxed font-light mb-6">
                    {serv.description}
                  </p>

                  {/* Expandible Technical Details Container */}
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      isExpanded ? 'max-h-80 opacity-100 mb-6' : 'max-h-0 opacity-0'
                    }`}
                  >
                    <div className="pt-4 border-t border-brand-gold/25 space-y-3">
                      <h4 className="text-xs font-mono font-semibold tracking-wider text-brand-gold uppercase pb-1">
                        Destaques e Aplicações Técnicas:
                      </h4>
                      {serv.details.map((detail, idx) => (
                        <div
                          key={idx}
                          className="flex items-start gap-2.5"
                        >
                          <CheckCircle className="w-4 h-4 text-brand-gold shrink-0 mt-0.5" />
                          <span className="text-xs text-brand-charcoal/80 font-light leading-relaxed">
                            {detail}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Interactive Toggle Trigger */}
                <button
                  onClick={() => toggleExpand(serv.id)}
                  className="w-full mt-auto flex items-center justify-center gap-1.5 py-3 px-4 rounded-xl border border-brand-gold/20 bg-white/5 hover:border-brand-gold hover:bg-brand-gold hover:text-black text-brand-gold text-xs font-semibold tracking-wider uppercase cursor-pointer transition-all duration-300"
                  aria-expanded={isExpanded}
                >
                  <span>{isExpanded ? 'Ocultar Detalhes' : 'Ver Detalhes'}</span>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                </button>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
