/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FAQS } from '../data';
import { Plus, Minus, Search, HelpCircle, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function FAQ() {
  const [openId, setOpenId] = useState<string | null>("faq-1");
  const [searchTerm, setSearchTerm] = useState("");

  const toggleAccordion = (id: string) => {
    if (openId === id) {
      setOpenId(null);
    } else {
      setOpenId(id);
    }
  };

  const filteredFaqs = FAQS.filter(
    (faq) =>
      faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faq.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <section
      id="faq"
      className="py-24 bg-[#0a0a0a] border-t border-b border-brand-gold/10"
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 font-sans">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-mono font-bold tracking-widest text-brand-gold uppercase">
            Esclareça Suas Dúvidas
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mt-2 mb-4">
            Perguntas Frequentes — FAQ
          </h2>
          <p className="text-sm sm:text-base text-brand-charcoal/80 leading-relaxed font-light">
            Tem alguma pergunta sobre o design biofílico, cronogramas de projetos ou custos extras sustentáveis? Encontre respostas rápidas aqui.
          </p>
          <div className="w-16 h-1 bg-brand-gold mx-auto mt-4 rounded-full" />
        </div>

        {/* Localized FAQ Search Field */}
        <div className="relative max-w-lg mx-auto mb-12" id="faq-search-wrapper">
          <input
            type="text"
            placeholder="Pesquise por termos (ex: obra, biofílico...)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3.5 bg-[#121212] border border-brand-gold/20 focus:border-brand-gold focus:ring-1 focus:ring-brand-gold outline-none rounded-2xl text-sm text-white font-light shadow-sm transition-all placeholder:text-brand-charcoal/40"
          />
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-brand-gold" />
          
          {/* Subtle counter bubble for search achievements */}
          {searchTerm && (
            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-mono bg-brand-gold text-black font-semibold rounded-full py-0.5 px-2">
              {filteredFaqs.length} {filteredFaqs.length === 1 ? 'resultado' : 'resultados'}
            </div>
          )}
        </div>

        {/* FAQs Accordion Block */}
        <div className="space-y-4" id="faq-accordions">
          {filteredFaqs.length > 0 ? (
            filteredFaqs.map((faq) => {
              const isOpen = openId === faq.id;
              return (
                <div
                  key={faq.id}
                  className="bg-[#121212] border border-brand-gold/15 rounded-2xl overflow-hidden transition-all duration-300 shadow-xl hover:border-brand-gold/35"
                >
                  {/* Button trigger */}
                  <button
                    onClick={() => toggleAccordion(faq.id)}
                    className="w-full text-left py-5 px-6 flex items-center justify-between gap-4 cursor-pointer outline-none group bg-[#121212] hover:bg-[#161616]"
                    aria-expanded={isOpen}
                  >
                    <div className="flex items-start gap-3">
                      <HelpCircle className="w-5 h-5 text-brand-gold shrink-0 mt-0.5" />
                      <span className="text-sm sm:text-base font-semibold text-white group-hover:text-brand-gold transition-colors">
                        {faq.question}
                      </span>
                    </div>

                    {/* Expand status indicators */}
                    <div className="w-8 h-8 rounded-full bg-white/5 border border-brand-gold/15 group-hover:bg-brand-gold group-hover:text-black text-brand-gold shrink-0 flex items-center justify-center transition-all">
                      {isOpen ? (
                        <Minus className="w-4 h-4 text-brand-gold group-hover:text-black" />
                      ) : (
                        <Plus className="w-4 h-4 text-brand-gold" />
                      )}
                    </div>
                  </button>

                  {/* Body Expand Animation Container */}
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      isOpen ? 'max-h-[300px] border-t border-brand-gold/10' : 'max-h-0'
                    }`}
                  >
                    <div className="p-6 bg-[#161616] text-brand-charcoal text-xs sm:text-sm leading-relaxed font-light space-y-2">
                      <p>{faq.answer}</p>
                      
                      <div className="flex items-center gap-1.5 pt-2">
                        <span className="text-[10px] font-mono font-bold text-brand-gold/80 uppercase tracking-widest pl-1">
                          Categoria: {faq.category}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center p-8 bg-[#121212] border border-dashed border-brand-gold/25 rounded-2xl flex flex-col items-center justify-center">
              <AlertCircle className="w-8 h-8 text-brand-gold mb-3 animate-bounce" />
              <p className="text-brand-charcoal/70 text-sm font-light">
                Não encontramos nenhuma pergunta com termos correspondentes a "<strong>{searchTerm}</strong>".
              </p>
              <button
                onClick={() => setSearchTerm("")}
                className="mt-3 px-4 py-1.5 bg-brand-gold hover:bg-[#a38051] text-black text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Limpar Busca
              </button>
            </div>
          )}
        </div>

        {/* FAQ Fallback helper block */}
        <div className="mt-12 text-center p-6 bg-[#121212] border border-brand-gold/15 rounded-2xl shadow-xl">
          <h4 className="text-sm font-bold text-white">Ainda tem alguma dúvida específica?</h4>
          <p className="text-xs text-brand-charcoal/70 mt-1">Nossa equipe está disponível para agendar uma chamada e analisar seus requisitos gratuitamente.</p>
          <a
            href="#contato"
            className="inline-block mt-4 text-xs font-bold text-brand-gold hover:text-white underline uppercase tracking-wider transition-colors"
          >
            Falar com um Consultor Especialista →
          </a>
        </div>

      </div>
    </section>
  );
}
