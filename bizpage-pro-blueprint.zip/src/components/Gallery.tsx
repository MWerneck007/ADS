/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GALERIA } from '../data';
import { Maximize2, X, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const categories = ['Todos', 'Residencial', 'Comercial', 'Paisagismo', 'Sistemas'];

  const filteredItems = selectedCategory === 'Todos'
    ? GALERIA
    : GALERIA.filter(item => item.category === selectedCategory);

  const openLightbox = (id: string) => {
    const idx = GALERIA.findIndex(item => item.id === id);
    if (idx !== -1) {
      setLightboxIndex(idx);
    }
  };

  const closeLightbox = () => {
    setLightboxIndex(null);
  };

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex + 1) % GALERIA.length);
    }
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex - 1 + GALERIA.length) % GALERIA.length);
    }
  };

  return (
    <section
      id="galeria"
      className="py-24 bg-[#0a0a0a]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 font-sans">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-mono font-bold tracking-widest text-brand-gold uppercase">
            Nosso Trabalho Visual
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mt-2 mb-4">
            Galeria de Projetos Realizados
          </h2>
          <p className="text-sm sm:text-base text-brand-charcoal/85 leading-relaxed font-light">
            Navegue pelos detalhes construtivos de algumas de nossas obras construídas sob diretrizes estritas de biofilia e sustentabilidade.
          </p>
          <div className="w-16 h-1 bg-brand-gold mx-auto mt-4 rounded-full" />
        </div>

        {/* Category Filter buttons */}
        <div className="flex flex-wrap justify-center items-center gap-2 mb-12" id="gallery-filters">
          <div className="flex items-center gap-2 text-brand-gold mr-2 text-xs font-mono uppercase tracking-widest font-bold">
            <Filter className="w-4 h-4" />
            <span>Filtro:</span>
          </div>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 sm:px-5 py-2 text-xs font-semibold rounded-full border cursor-pointer transition-all duration-300 ${
                selectedCategory === cat
                  ? 'bg-brand-gold text-black border-brand-gold shadow-md'
                  : 'bg-white/5 text-brand-charcoal border-brand-gold/20 hover:border-brand-gold hover:bg-brand-gold/10 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Gallery Image Grid with interactive zoom overlay */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          id="gallery-grid"
        >
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                key={item.id}
                className="group relative bg-[#121212]/90 rounded-2xl overflow-hidden border border-brand-gold/15 hover:border-brand-gold/40 transition-all duration-300 aspect-[4/3] flex flex-col cursor-pointer shadow-2xl"
                onClick={() => openLightbox(item.id)}
              >
                {/* Image panel */}
                <div className="relative w-full h-full overflow-hidden flex-1">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  {/* Dark mask overlay on hover */}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center pointer-events-none">
                    <div className="w-10 h-10 bg-[#161616] border border-brand-gold/30 rounded-full flex items-center justify-center text-brand-gold shadow-lg">
                      <Maximize2 className="w-5 h-5 text-brand-gold" />
                    </div>
                  </div>

                  {/* Top Category Badge */}
                  <div className="absolute top-4 left-4 bg-[#121212]/90 backdrop-blur-sm py-1 px-3 rounded-full text-[10px] font-mono font-bold text-brand-gold border border-brand-gold/25 uppercase">
                    {item.category}
                  </div>
                </div>

                {/* Sub text banner */}
                <div className="p-4 border-t border-brand-gold/10 group-hover:bg-[#1a1a1a] transition-colors">
                  <h4 className="text-sm font-bold text-white leading-tight group-hover:text-brand-gold transition-colors">
                    {item.title}
                  </h4>
                  <p className="text-[11px] text-brand-charcoal/70 truncate mt-1">
                    {item.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Modal Lightbox */}
        <AnimatePresence>
          {lightboxIndex !== null && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-4 md:p-6"
              onClick={closeLightbox}
            >
              {/* Close Button overlay */}
              <button
                className="absolute top-6 right-6 p-2 text-brand-charcoal hover:bg-brand-gold/20 rounded-xl transition-colors cursor-pointer"
                onClick={closeLightbox}
                id="lightbox-close"
              >
                <X className="w-7 h-7 text-brand-gold" />
              </button>

              {/* Slider Image frame */}
              <div
                className="relative max-w-4xl w-full flex flex-col items-center text-center bg-[#121212] border border-brand-gold/35 rounded-2xl overflow-hidden shadow-2xl mt-4 max-h-[85vh]"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Active Image container */}
                <div className="relative w-full aspect-video max-h-[50vh] bg-neutral-900 flex items-center justify-center">
                  <img
                    src={GALERIA[lightboxIndex].imageUrl}
                    alt={GALERIA[lightboxIndex].title}
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />

                  {/* Left / Right Arrow buttons */}
                  <button
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-[#1a1a1a]/90 hover:bg-brand-gold text-brand-gold hover:text-black flex items-center justify-center cursor-pointer shadow-lg border border-brand-gold/20 outline-none transition-colors"
                    onClick={prevImage}
                    title="Anterior"
                  >
                    ‹
                  </button>
                  <button
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-[#1a1a1a]/90 hover:bg-brand-gold text-brand-gold hover:text-black flex items-center justify-center cursor-pointer shadow-lg border border-brand-gold/20 outline-none transition-colors"
                    onClick={nextImage}
                    title="Próxima"
                  >
                    ›
                  </button>
                </div>

                {/* Info block footer */}
                <div className="p-6 bg-[#121212] border-t border-brand-gold/25 w-full text-left">
                  <span className="text-[10px] font-mono font-bold tracking-widest text-[#9D8466] uppercase">
                    PROJETO REALIZADO • {GALERIA[lightboxIndex].category}
                  </span>
                  <h3 className="text-xl font-serif font-bold text-white mt-1">
                    {GALERIA[lightboxIndex].title}
                  </h3>
                  <p className="text-sm text-brand-charcoal/80 font-light leading-relaxed mt-2">
                    {GALERIA[lightboxIndex].description}
                  </p>
                </div>
              </div>

              {/* Counter status label */}
              <div className="text-xs font-mono text-brand-gold mt-4 bg-black/80 py-1.5 px-4 rounded-full border border-brand-gold/25">
                Residência {lightboxIndex + 1} de {GALERIA.length}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
