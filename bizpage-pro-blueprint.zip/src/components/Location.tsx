/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MapPin, Mail, Phone, Clock, ExternalLink } from 'lucide-react';
import { COMPANHIA_INFO } from '../data';

export default function Location() {
  return (
    <section
      className="py-24 bg-[#0a0a0a] relative overflow-hidden font-sans"
      id="localizacao-secao"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-brand-gold uppercase">
            Visite-nos
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mt-2 mb-4">
            Nossa Localização &amp; Detalhes
          </h2>
          <p className="text-sm sm:text-base text-brand-charcoal/80 leading-relaxed font-light">
            Estamos situados no coração empresarial de São Paulo. Venha tomar um café em nosso escritório ecológico de demonstração biofílica.
          </p>
          <div className="w-16 h-1 bg-brand-gold mx-auto mt-4 rounded-full" />
        </div>

        {/* Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-stretch">
          
          {/* Left Column: Office Details */}
          <div className="lg:col-span- de-fato lg:col-span-5 flex flex-col justify-between">
            <div className="space-y-8" id="location-details">
              
              <div>
                <span className="text-[10px] font-mono font-bold text-brand-gold uppercase tracking-wider block mb-2">
                  Sede Central em São Paulo
                </span>
                <h3 className="text-xl font-serif font-semibold text-brand-gold">
                  Espaço Demo Aura Itaim
                </h3>
                <p className="text-xs sm:text-sm text-brand-charcoal/70 mt-3 font-light leading-relaxed">
                  Nosso saguão possui purificadores de ar automatizados, plantas nativas monitoradas e painéis bio-acústicos para que você experimente os benefícios em tempo real antes de projetar.
                </p>
              </div>

              {/* Informative Items */}
              <div className="space-y-6">
                
                {/* Physical Location */}
                <div className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-xl bg-brand-gold/10 text-brand-gold flex items-center justify-center shrink-0 border border-brand-gold/15">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
                      Endereço Comercial
                    </h4>
                    <p className="text-xs sm:text-sm text-brand-charcoal/80 leading-relaxed font-light mt-1">
                      {COMPANHIA_INFO.endereco}
                    </p>
                  </div>
                </div>

                {/* Telephone */}
                <div className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-xl bg-brand-gold/10 text-brand-gold flex items-center justify-center shrink-0 border border-brand-gold/15">
                    <Phone className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wide text-white">
                      Telefone &amp; Atendimento
                    </h4>
                    <p className="text-xs sm:text-sm text-brand-charcoal/80 leading-relaxed font-light mt-1">
                      {COMPANHIA_INFO.telefone}
                    </p>
                  </div>
                </div>

                {/* Mail inbox */}
                <div className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-xl bg-brand-gold/10 text-brand-gold flex items-center justify-center shrink-0 border border-brand-gold/15">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wide text-white">
                      Correio Eletrônico
                    </h4>
                    <p className="text-xs sm:text-sm text-brand-charcoal/80 leading-relaxed font-light mt-1">
                      {COMPANHIA_INFO.email}
                    </p>
                  </div>
                </div>

                {/* Opening Hours */}
                <div className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-xl bg-brand-gold/10 text-brand-gold flex items-center justify-center shrink-0 border border-brand-gold/15">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wide text-white">
                      Horário de Funcionamento
                    </h4>
                    <p className="text-xs sm:text-sm text-brand-charcoal/80 leading-relaxed font-light mt-1">
                      {COMPANHIA_INFO.funcionamento}
                    </p>
                  </div>
                </div>

              </div>

            </div>

            {/* Direct Google Maps Navigation Link */}
            <div className="mt-8 pt-6 border-t border-brand-gold/15">
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-brand-gold hover:bg-[#a38051] text-black text-xs font-mono font-bold tracking-wider uppercase transition-all duration-300 shadow-md hover:scale-[1.02]"
              >
                <span>Rotas no Google Maps</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Right Column: Embedded Functional Map */}
          <div className="lg:col-span-7" id="location-map-frame">
            <div className="w-full h-full min-h-[350px] rounded-3xl overflow-hidden shadow-2xl border-4 border-brand-gold/25 relative group">
              {/* Responsive Iframe using OpenStreetMap coordinates for Faria Lima, SP */}
              <iframe
                title="Aura Itaim Bibi headquarters Map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3656.1287954930104!2d-46.68536838502157!3d-23.599723284664287!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1m3!1d1!2sAv.%20Brigadeiro%20Faria%20Lima%2C%204500%20-%20Itaim%20Bibi%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004538-132!5e0!3m2!1spt-BR!2sbr!4v1685331590321!5m2!1spt-BR!2sbr"
                width="100%"
                height="100%"
                className="min-h-[350px] w-full h-full border-0 rounded-2xl group-hover:scale-[1.01] transition-transform duration-500 bg-[#121212]"
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
