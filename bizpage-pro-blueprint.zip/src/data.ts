/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ServiceItem,
  FAQItem,
  TeamMember,
  GalleryItem,
  TestimonialItem,
  ValueItem,
  StatItem
} from './types';

export const COMPANHIA_INFO = {
  nome: "Aura Arquitetura & Design",
  slogan: "Arquitetura viva que se conecta com a sua essência",
  subtitulo: "Projetos inovadores que mesclam o design biofílico, eficiência energética e elegância contemporânea para criar ambientes saudáveis, sustentáveis e inspiradores.",
  historia: "Fundada em 2018 com o propósito de redefinir nossa relação com os espaços construídos, a Aura surgiu da união entre arquitetos visionários e engenheiros ambientais. Percebemos que as pessoas passam mais de 90% do tempo em ambientes fechados — muitas vezes desconectadas da luz natural e do verde. Diante disso, decidimos trazer a natureza de volta para a rotina urbana por meio de projetos integrados. Ao longo da nossa trajetória, criamos residências que respiram, escritórios corporativos focados no bem-estar mental e espaços públicos que regeneram o ecossistema local.",
  missao: "Desenvolver soluções arquitetônicas de alto padrão que harmonizam a vida humana com a natureza, aplicando tecnologias ecológicas e design biofílico para elevar a saúde, o bem-estar e a sustentabilidade global.",
  visao: "Ser a principal referência na América Latina em arquitetura sustentável de luxo, liderando a transição do mercado para edificações autossuficientes, saudáveis e integradoras com a biodiversidade.",
  endereco: "Av. Faria Lima, 4500 - Itaim Bibi, São Paulo - SP, 04538-132",
  telefone: "(11) 3205-0010",
  email: "contato@auraarquitetura.com.br",
  funcionamento: "Segunda a Sexta, das 09h às 18h",
  redesSociais: {
    instagram: "https://instagram.com/aura.arq",
    linkedin: "https://linkedin.com/company/aura-arquitetura",
    pinterest: "https://pinterest.com/aura_concept",
    youtube: "https://youtube.com/aura_arquitetura"
  }
};

export const VALORES: ValueItem[] = [
  {
    title: "Eco-Consciência",
    description: "Cada decisão projetual prioriza materiais de baixo impacto ecológico e eficiência energética duradoura.",
    iconName: "Leaf"
  },
  {
    title: "Design Biofílico",
    description: "Integração autêntica de elementos naturais, texturas orgânicas e correntes de ar para regeneração humana.",
    iconName: "Trees"
  },
  {
    title: "Inovação Responsável",
    description: "Uso de tecnologias inteligentes para controle de recursos, coleta de água pluvial e energia circular.",
    iconName: "Cpu"
  },
  {
    title: "Excelência Estética",
    description: "Acreditamos que a sustentabilidade e a sofisticação andam juntas na criação de formas perenes e belas.",
    iconName: "Sparkles"
  }
];

export const SERVICOS: ServiceItem[] = [
  {
    id: "serv-residencial",
    title: "Residências Biofílicas",
    subtitle: "Casas que respiram e se adaptam",
    description: "Concepção de lares que integram jardins internos, iluminação zenital calculada e materiais térmicos naturais, promovendo o refúgio perfeito contra o estresse moderno.",
    iconName: "Home",
    details: [
      "Ventilação natural cruzada inteligente",
      "Iluminadores zenitais e solários estrategicamente posicionados",
      "Paredes verdes interiores e painéis de madeira certificada",
      "Planejamento com base no ciclo circadiano dos proprietários"
    ]
  },
  {
    id: "serv-corporativo",
    title: "Corporativos Regenerativos",
    subtitle: "Produtividade aliada ao bem-estar",
    description: "Espaços de trabalho sob medida que reduzem a fadiga mental, melhoram a qualidade do ar interior e incentivam a colaboração harmônica através do contato com o natural.",
    iconName: "Building2",
    details: [
      "Redução de até 15% nos níveis de estresse conforme design biofílico",
      "Sistemas avançados de purificação vegetal de ar",
      "Controle acústico orgânico com elementos de musgo desidratado",
      "Uso massivo de luz natural reduzindo consumo elétrico"
    ]
  },
  {
    id: "serv-tecnologia",
    title: "Sistemas Sustentáveis & Energia",
    subtitle: "Autossuficiência e inteligência ecológica",
    description: "Integração de centrais solares integradas, sistemas de reúso de água cinza, compostagem automatizada e automação residencial focada no consumo zero de carbono.",
    iconName: "BatteryCharging",
    details: [
      "Pergolados solares estéticos e telhados verdes ativos",
      "Tratamento de águas residuais no próprio local",
      "Sistemas de climatização geotérmica e passiva",
      "Sensores de desempenho ambiental monitorados por aplicativo"
    ]
  },
  {
    id: "serv-paisagismo",
    title: "Paisagismo Ecossistêmico",
    subtitle: "Jardins que curam e atraem vida",
    description: "Projetos de paisagismo que vão além da decoração: são microclimas nativos projetados para atrair fauna local, demandar baixo consumo hídrico e acalmar os sentidos.",
    iconName: "Flower",
    details: [
      "Seleção estrita de espécies nativas e adaptadas ao clima local",
      "Sistemas de irrigação gota a gota micro-controlados",
      "Criação de biótopos e espelhos d'água ecológicos",
      "Áreas sensoriais com aromas e texturas terapêuticas"
    ]
  }
];

export const DIFERENCIAIS = [
  {
    id: "dif-1",
    title: "Carbono Neutro Garantido",
    description: "Neutralizamos 100% da pegada de carbono da fase de construção e instalação de todos os nossos projetos.",
    icon: "ShieldAlert"
  },
  {
    id: "dif-2",
    title: "Certificações de Prestígio",
    description: "Nossos projetos são criados sob diretrizes rígidas visando as certificações internacionais LEED, WELL e Fitwel.",
    icon: "Award"
  },
  {
    id: "dif-3",
    title: "Qualidade do Ar Interno",
    description: "Garantimos monitoramento e filtragem natural de poluentes para ambientes incrivelmente oxigenados.",
    icon: "Wind"
  },
  {
    id: "dif-4",
    title: "Personalização Baseada em Neuroarquitetura",
    description: "Estudamos os impactos neurológicos de cada cor, forma e som projetado, moldando bem-estar real no seu dia a dia.",
    icon: "Activity"
  }
];

export const METRICAS: StatItem[] = [
  { number: "80", label: "Projetos Entregues", suffix: "+" },
  { number: "15", label: "Prêmios de Design", suffix: "" },
  { number: "40", label: "Mil M² de Área Verde Criada", suffix: "k" },
  { number: "100", label: "Clientes Satisfeitos", suffix: "%" }
];

export const TIME: TeamMember[] = [
  {
    id: "tm-1",
    name: "Dr. Sofia Alencar",
    role: "Sócia-Fundadora & Diretora de Criação",
    bio: "Doutora em Arquitetura com foco em Design Biofílico e Neuroarquitetura. Tem mais de de 12 anos de atuação na projeção de refúgios ecológicos luxuosos na Europa e no Brasil.",
    imageUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=400&auto=format&fit=crop",
    linkedin: "https://linkedin.com",
    instagram: "https://instagram.com"
  },
  {
    id: "tm-2",
    name: "Thiago Vasconcellos",
    role: "Arquiteto-Chefe & Urbanista",
    bio: "Pós-graduado em Cidades Inteligentes e Sustentáveis. Lidera a transição de formas complexas em sistemas construtivos eficientes, leves e altamente integrados com madeira engenheirada.",
    imageUrl: "https://images.unsplash.com/photo-1556157382-97eda2d62296?q=80&w=400&auto=format&fit=crop",
    linkedin: "https://linkedin.com",
    instagram: "https://instagram.com"
  },
  {
    id: "tm-3",
    name: "Helena Moreira",
    role: "Diretora de Engenharia Ambiental & Paisagista",
    bio: "Especialista em botânica aplicada e hidrologia urbana. Desenha os sistemas e ecossistemas fechados de tratamento de águas e bio-climatização ativa de nossos mega-projetos.",
    imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=400&auto=format&fit=crop",
    linkedin: "https://linkedin.com"
  }
];

export const DEPOIMENTOS: TestimonialItem[] = [
  {
    id: "dep-1",
    name: "Mariana Siqueira",
    company: "Residência Alvoroço",
    role: "Proprietária Residencial",
    text: "Morar em uma casa projetada pela Aura transformou absolutamente a nossa dinâmica de família. É como viver de férias em meio à floresta, mas no coração de São Paulo. A luminosidade zenital e o jardim interno trouxeram uma paz indescritível para nosso cotidiano.",
    rating: 5,
    imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=150&auto=format&fit=crop"
  },
  {
    id: "dep-2",
    name: "Daniel Farias",
    company: "GoGreen Tech Hub",
    role: "Diretor de Operações",
    text: "Nossos colaboradores relatam melhora evidente na concentração e cansaço visual desde que nos mudamos para a nova sede integrada projetada pela Aura. O investimento no bem-estar biofílico se pagou em poucos meses por meio do engajamento e redução de turnover.",
    rating: 5,
    imageUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=150&auto=format&fit=crop"
  },
  {
    id: "dep-3",
    name: "Beatriz e Gustavo Ramos",
    company: "Casa Âmbar",
    role: "Empresários",
    text: "O acompanhamento técnico da Aura do início ao fim nos deu uma tranquilidade absoluta. Toda a complexidade dos painéis solares, cisternas ocultas e climatização cruzada foi cuidada pela equipe especialista deles de forma simples e transparente.",
    rating: 5,
    imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=150&auto=format&fit=crop"
  }
];

export const GALERIA: GalleryItem[] = [
  {
    id: "gal-1",
    title: "Casa Suspensa de Madeira",
    category: "Residencial",
    imageUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1000&auto=format&fit=crop",
    description: "Residência de veraneio sustentável erguida de modo suspenso sobre solo arenoso nativo preservando as árvores ancestrais de seu entorno."
  },
  {
    id: "gal-2",
    title: "Saguão Biofílico Corporativo",
    category: "Comercial",
    imageUrl: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=1000&auto=format&fit=crop",
    description: "Foyer de entrada de empresa com painéis acústicos de musgo preservado, cascatas de água de reúso e clarabóias ecológicas."
  },
  {
    id: "gal-3",
    title: "Oásis Urbano de Água",
    category: "Paisagismo",
    imageUrl: "https://images.unsplash.com/photo-1508248467877-9c6a76f20732?q=80&w=1000&auto=format&fit=crop",
    description: "Lago ornamental e adaptado de tratamento biológico para um condomínio residencial de baixa densidade energética."
  },
  {
    id: "gal-4",
    title: "Loft da Copa das Árvores",
    category: "Residencial",
    imageUrl: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1000&auto=format&fit=crop",
    description: "Apartamento duplex com extensos beirais envidraçados, floreiras autóctones suspensas e móveis orgânicos de tora restaurada."
  },
  {
    id: "gal-5",
    title: "Escritório Jardim Vertical",
    category: "Comercial",
    imageUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1000&auto=format&fit=crop",
    description: "Estações de trabalho otimizadas com divisórias de bambu natural vivo e circulação inteligente de ventilação mecânica limpa."
  },
  {
    id: "gal-6",
    title: "Pergola e Painéis Solares Ativos",
    category: "Sistemas",
    imageUrl: "https://images.unsplash.com/photo-1509391366360-2e959784a276?q=80&w=1000&auto=format&fit=crop",
    description: "Pergolados de sombreamento integrando coletores de energia solar de última geração, cobrindo uma área de convívio social externa."
  }
];

export const FAQS: FAQItem[] = [
  {
    id: "faq-1",
    question: "O que é exatamente o Design Biofílico?",
    answer: "É uma metodologia que busca conectar as pessoas de volta à natureza dentro das edificações. Isso é alcançado não apenas colocando vasos de plantas, mas integrando iluminação natural difusa, vista para ecossistemas, sons sutis de água, ventilação ativa refrescante e texturas que emulam formas biológicas que atuam no sistema autônomo, reduzindo o estresse e acelerando o bem-estar.",
    category: "Conceito"
  },
  {
    id: "faq-2",
    question: "A Aura constrói os projetos ou realiza apenas o projeto de arquitetura?",
    answer: "Nós fazemos a concepção completa do projeto arquitetônico, paisagístico e de engenharia de sustentabilidade ambiental. Para a execução da obra, nós atuamos em parceria estreita com construtoras altamente qualificadas de sua escolha, prestando acompanhamento cuidadoso e completo da obra para garantir fidelidade total ao projeto, montagem dos sistemas de energia e plantios ecológicos.",
    category: "Serviço"
  },
  {
    id: "faq-3",
    question: "Os projetos sustentáveis de alto padrão são muito mais caros?",
    answer: "Historicamente, há um acréscimo médio de 5% a 8% no custo construtivo inicial para integrar isolantes extras, painéis fotovoltaicos e sistemas de captação de água pluvial. No entanto, este valor retorna inteiramente em economia de luz e água em 3 a 5 anos de uso ativo, convertendo-se em economia financeira pura a partir de então, além do ganho imensurável de saúde.",
    category: "Custo"
  },
  {
    id: "faq-4",
    question: "Como funciona a garantia de neutralidade de carbono?",
    answer: "Nós realizamos um cálculo preciso (inventário de emissões) dos gases estufa associados a todo o frete de materiais estruturais, consumo de cimento, madeira e energia da obra de nossos projetos. Em seguida, a Aura investe no plantio certificado de florestas nativas e créditos de conservação no bioma amazônico para contrabalançar 100% desse impacto, entregando seu laudo oficial certificado aos donos.",
    category: "Sustentabilidade"
  },
  {
    id: "faq-5",
    question: "Posso aplicar o design biofílico mesmo em um apartamento pequeno já existente?",
    answer: "Com certeza absoluta! Através de projetos integrados de Interiores Biofílicos, nós reorganizamos o layout para aproximar os pontos de vivência da iluminação natural favorável, instalamos jardins verticais irrigados, trocamos revestimentos por matérias-primas naturais e planejamos uma iluminação circadiana que melhora significativamente sua qualidade do sono.",
    category: "Conceito"
  }
];
